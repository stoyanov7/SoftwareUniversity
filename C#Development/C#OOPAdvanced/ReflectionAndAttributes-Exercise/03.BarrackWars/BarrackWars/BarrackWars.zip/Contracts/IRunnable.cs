﻿namespace BarrackWars.Contracts
{
    public interface IRunnable
    {
        void Run();
    }
}
