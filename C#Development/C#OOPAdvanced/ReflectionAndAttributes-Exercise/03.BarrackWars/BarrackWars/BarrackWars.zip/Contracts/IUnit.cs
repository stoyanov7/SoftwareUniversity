﻿namespace BarrackWars.Contracts
{
    public interface IUnit : IDestroyable, IAttacker
    {

    }
}
