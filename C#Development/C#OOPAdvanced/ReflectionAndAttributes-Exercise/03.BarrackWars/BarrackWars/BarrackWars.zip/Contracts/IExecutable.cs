﻿namespace BarrackWars.Contracts
{
    public interface IExecutable
    {
        string Execute();
    }
}
