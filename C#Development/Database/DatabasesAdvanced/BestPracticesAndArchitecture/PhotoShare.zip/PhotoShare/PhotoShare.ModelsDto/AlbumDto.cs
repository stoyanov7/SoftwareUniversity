﻿namespace PhotoShare.ModelsDto
{
    public class AlbumDto
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
