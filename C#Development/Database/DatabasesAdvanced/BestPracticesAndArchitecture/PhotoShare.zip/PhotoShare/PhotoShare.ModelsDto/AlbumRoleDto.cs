﻿namespace PhotoShare.ModelsDto
{
    public class AlbumRoleDto
    {
        public string Username { get; set; }

        public string AlbumName { get; set; }
    }
}
