﻿namespace PhotoShare.ModelsDto
{
    public class UserDto
    {
        public int Id { get; set; }

        public string Username { get; set; }

        public bool? IsDeleted { get; set; }
    }
}
