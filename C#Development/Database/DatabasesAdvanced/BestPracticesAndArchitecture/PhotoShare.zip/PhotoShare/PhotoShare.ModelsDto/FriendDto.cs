﻿namespace PhotoShare.ModelsDto
{
    public class FriendDto
    {
        public string Username { get; set; }
    }
}
