﻿namespace PhotoShare.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
